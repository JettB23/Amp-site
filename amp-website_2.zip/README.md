# AMP — Andrew McLaggan Projects

Fifteen pages, static HTML. No build step, no framework, no dependencies.
Open `index.html`.

Built against the Ignite For Men reference: warm and welcoming rather than
coldly minimal, photography-led, conversion-first. Service cards, a founder
story, proof metrics, "what's included" modules and a low-friction CTA
repeated throughout.

---

## Two copies of the site

```
/                    The real site. Shared CSS, shared JS, shared logo files.
                     This is what gets deployed.

/standalone/         The same fifteen pages, each one self-contained: CSS,
                     JS and logos inlined as base64. Every file opens
                     correctly on its own, from anywhere, with no folder
                     around it. For review and sign-off only — never deploy
                     these; the CSS and JS are duplicated fifteen times.
```

Edit the real site. Regenerate `/standalone/` afterwards.

---

## Pages

```
index.html                     Home
services.html                  What We Do — all four capabilities
service-outdoor-kitchens.html  Detail page
service-pergolas.html          Detail page
service-decking.html           Detail page
service-cabinetry.html         Detail page
work.html                      Project index
project.html                   Project detail TEMPLATE — copy per build
about.html                     Father & son story, standards
planner.html                   Build Planner — interactive, see below
guide.html                     Nine things to sort out before you build
for-architects.html            For architects, designers and builders
contact.html                   Enquiry form + FAQ
privacy.html                   POPIA privacy notice
404.html                       Not found

assets/css/amp.css             One stylesheet, shared
assets/js/amp.js               One script, shared
assets/*.png                   Logo, four variants
sitemap.xml  robots.txt
```

Every page shares the same header, footer and mobile dock, so a navigation
change needs making in each file — or move to a static site generator when
the page count grows past this.

---

## Design

Warm cream ground (`#FAF7F1`) so the site feels welcoming rather than
corporate. Royal blue from the AMP logo (`#0B3C7D`) carries brand, links and
every action. Ochre (`#B87A33`) appears only behind dark text, never as small
type — it would fail contrast. Every text pair clears WCAG AA 4.5:1.

Newsreader for headlines — warm, readable, not precious. Figtree for
everything else. One radius (14px), one shadow scale, one spacing rhythm.

Two class families that look similar and are not: `.d1`–`.d4` are display
font sizes. `.dl1`–`.dl4` are scroll-reveal delays. They collided once and
cost an afternoon. Do not merge them.

Scroll reveals use IntersectionObserver with a 2.6s failsafe that reveals
everything regardless. Without it, any element the observer never fires on
stays invisible forever — which is exactly what happened to a `clip-path`
element reporting zero intersection area. Keep the failsafe.

Logos are sized for how they actually render — the footer wordmark at
560px for a 230px slot, the header mark at 240px for an 87px slot, both
comfortably retina. They were 900px and 420px originally, which cost
270KB for no visible gain. Resize to roughly 2.4x the rendered size if
you ever replace them.

---

## The Build Planner

`planner.html`. The visitor picks a build type, drags width, depth and
height, and chooses options — roof style, braai type, sink, worktop,
deck level, railings. A scale drawing redraws live, with dimensions and
annotations, and a written spec builds alongside it.

The drawings are **parametric SVG computed from state**, not swapped
images. One state object drives four draw functions:

```js
var S = { type:'pergola', width:5, depth:3.5, height:2.7,
          roof:'louvred', attach:'free', braai:'wood', sink:true,
          fridge:false, top:'granite', level:'raised', rail:true,
          steps:true, config:'mixed' };
var DRAW = { pergola:drawPergola, kitchen:drawKitchen,
             deck:drawDeck, cabinetry:drawCab };
```

Add an option by extending `S`, reading it inside the relevant draw
function, and adding the control. Nothing else needs touching.

**It shows no prices.** Instead it shows four relative cost drivers as
bars — size and span, materials and hardware, services to run in, site
complexity — so the visitor understands what moves a quote without being
given a number that later turns out wrong. Pricing depends entirely on
quotation; keep it that way.

"Send this to AMP" hands the full spec to `contact.html` through URL query
parameters, which pre-fill the enquiry form. The visitor arrives at the
form having already done the thinking, which is the whole point: it turns
a browser into a qualified enquiry, and it works with zero photography.

---

## RGD trust blueprint

Marked through the markup with `RGD·` comments.

**TRUST** — hero subline · the proof strip under the hero · father-and-son
story · "How it works" · the standards block on About · the guide, which
gives away real expertise before asking for anything · the planner, which
shows the work being thought through · per-page FAQs that kill the
objections that stop people enquiring · "the same two people design it,
build it and install it".

**FOMO** — wine farms, estates and private homes · areas served ·
*"Most of our work comes from referrals from estates and architects."*

**SCARCITY** — the availability pill above the headline · Limited Bookings
panel · 4–6 weeks stated on every page · "Reserve Your Build Slot" and
"Check Availability" rather than "get a quote".

**The booking month calculates itself** — today plus the stated five-week
average, printed as a month name (`[CURRENT_BOOKING_MONTH]`). No monthly
admin and it can never go stale. To set it by hand, search
`data-book-month` in `amp.js`.

---

## Dark mode

The sun/moon button in the header (top right, next to the phone number)
switches the theme. The choice is kept in `localStorage` under `amp-theme`
and survives navigation. Until a visitor chooses, the site follows their
operating system, and keeps following it if the OS flips mid-visit. A tiny
inline script in each page's `<head>` applies the theme before first paint,
so there is no flash of the wrong theme on load.

The whole dark theme is one token override block in `amp.css`
(`:root[data-theme="dark"]`) — no component has a dark-specific rule.
Three token families make that work; keep new CSS on them:

- `--blue` is the **accent** — text, links, icons. It lightens in dark mode.
- `--fill` / `--fill-deep` are **solid brand surfaces** — bands, buttons,
  the footer. They stay dark in both themes, so text on them stays white.
  Never use `--blue` as a background.
- `--card` / `--cream` / `--sand` are the page surfaces.

Both themes pass WCAG AA on every text pair — checked by rendering all
fifteen pages in both themes and computing contrast on every text node,
not by eyeballing. Re-run that audit after any colour change.

---

## SEO

- One `<h1>` per page, unique `<title>` and meta description on all fifteen.
- JSON-LD: `HomeAndConstructionBusiness` sitewide, plus `Service` on each
  service page, `FAQPage` where there are FAQs, `BreadcrumbList` on
  every inner page, `Article` on the guide.
- Visible breadcrumbs on twelve pages; related-links blocks on eleven.
  Service pages carry twelve internal links each.
- Every cross-page CTA band is **contextually unique** — eleven different
  headings and body texts. They were byte-identical once, which is a
  duplicate-content signal and reads as boilerplate to a human too.
- Per-page FAQs are unique across the four service pages, as are the photo
  briefs and the guidance notes.

Duplication was measured, not guessed: a sentence-frequency count found
nineteen cross-page duplicate sentences, several appearing on eleven to
thirteen pages. That is now nine, and the remainder is footer boilerplate,
which is normal and correct. **Re-run that count after any bulk copy
change** — shared header/footer builders make duplication easy to
reintroduce without noticing.

**No per-suburb landing pages.** "Outdoor kitchens in Somerset West",
"… in Stellenbosch" and so on would be thin doorway pages until there are
real projects in each area to put on them. Build them when the photography
and the project write-ups exist, one page per area with genuinely
different content, or not at all.

---

## The enquiry form

Four steps with live validation, a review summary before sending, and a
honeypot for spam. **It works without a backend**: on submit it composes a
structured email — project type, area, scope, timing, budget, description
and contact details — and opens the sender's mail client. It also accepts
pre-filled values from the planner.

To POST instead, add an endpoint:

```html
<form id="enq" action="https://formspree.io/f/xxxxxxx" data-to="..." novalidate>
```

Formspree, Basin, Web3Forms and Netlify Forms all work. The script detects
`action`, POSTs, and falls back to email if the request fails.

---

## Adding photography

Replace each `<div class="ph …">` with:

```html
<picture>
  <source srcset="assets/img/pergola-01.avif" type="image/avif">
  <source srcset="assets/img/pergola-01.webp" type="image/webp">
  <img src="assets/img/pergola-01.jpg"
       alt="Louvred pergola over a paved patio, oiled timber posts"
       width="1600" height="1067" loading="lazy" decoding="async">
</picture>
```

2400px long edge, AVIF + WebP at ~q72, JPEG fallback. The first image on
each page gets `loading="eager"` and `fetchpriority="high"`. Alt text
describes the build, not the project name.

Every placeholder carries a written shot brief, and the briefs differ per
page — hand that list to whoever shoots the two jobs being finished now.

---

## Adding a project

Copy `project.html` to a clean slug (`project-somerset-west-kitchen.html`),
update the title, description, photos and every `[TOKEN]`, then add a card
to `work.html` and to the homepage's Recent Builds section. Update
`sitemap.xml`.

---

## Regenerating /standalone/

Inline the shared CSS, the shared JS and the four logo PNGs as base64,
then assert that no relative asset reference survives:

```python
s = s.replace('<link rel="stylesheet" href="assets/css/amp.css">',
              "<style>\n" + css + "\n</style>")
s = s.replace('<script src="assets/js/amp.js" defer></script>',
              "<script>\n" + js + "\n</script>")
# only RELATIVE refs break a standalone file —
# absolute JSON-LD URLs legitimately contain "assets/"
assert not re.findall(r'(?:href|src)="assets/[^"]*"', s), name
```

That assertion is the whole safety net. A standalone file that still
points at `assets/` renders as unstyled text when opened alone.

---

## Outstanding from the client

**1 — Contact details.** Phone is in: 082 967 0541 (tel links use
+27829670541). Still outstanding: `[EMAIL_ADDRESS]` and
`[WHATSAPP_NUMBER]`. The form cannot deliver without the email address —
**that still blocks launch** — and the WhatsApp dock button goes nowhere
until its number is confirmed (do not assume it is the same number).

**2 — Photography.** Two jobs are being finished now. Per build: one wide
hero frame, one or two details, one in-use. Plus one photo of Andrew and
Cameron working — that is the single most valuable image on the site. Get
the homeowner's permission before anything is published.

**3 — Budget bands.** `[BUDGET_BAND_1…4]` on the contact form. Deliberately
left empty rather than guessed. They are what stop Andrew spending evenings
quoting jobs that were never viable.

**4 — Two FAQ answers.** `[PRICING_ANSWER]` and `[WARRANTY_INFORMATION]`.
Saying nothing about price loses enquiries; guessing loses trust. The
guarantee is a contractual statement — publish nothing that isn't agreed.

**5 — Service detail.** `[OUTDOOR_KITCHEN_DETAIL]`, `[PERGOLA_DETAIL]`,
`[DECKING_DETAIL]`, `[CABINETRY_DETAIL]`, plus the four `[*_LEAD_TIME]`
tokens. Name the actual timber, the louvre system, the decking
substructure. Specifics are what separate AMP from a general builder in a
reader's mind — and they are what the search traffic is actually looking
for.

**6 — `[CONSULTATION_TERMS]`.** The hero says "We come out, look at the
space and talk it through" — if that visit is free, say so. It is the
cheapest friction remover on the page, which is exactly what the reference
site does with "$0 for first 30 minutes".

**7 — `[JOBS_PER_MONTH]`, `[RESPONSE_TIME]`, `[OTHER_AREAS]`.** Small
numbers that make the scarcity and the service promise concrete instead of
vague.

**8 — Project write-ups, testimonials, bios, socials, registration
details, `[ANDREW_TRADE_BACKGROUND]`, `[ACCREDITATIONS]`.**

Run `grep -ohP '\[[A-Z_0-9]{3,}\]' *.html | sort | uniq -c | sort -rn`
for the live list at any time. **Nothing ships with a `[TOKEN]` visible.**

---

## Two deliberate departures from the supplied copy

**The trust bar.** It originally had "Based in Helderberg" *and* "Custom
Built In The Helderberg" — two of five items making the same point. The
proof strip now reads 30+ Years / Father & Son / One project at a time /
4–6 weeks.

**The register.** The supplied copy was written as an email — "My dad…",
"I joined him…", "we're not it". Every fact is used exactly as given; the
voice was changed to read as a company that builds for high-value clients
rather than a personal note. No claim was added, removed or softened in
the process.

## Craft motion (amp.css §27, amp.js "CRAFT MOTION")

A small vocabulary of movements, used the same way everywhere:

| Motif | Where | Hook |
|---|---|---|
| Pencil line | under every `.eyebrow`; under "Built to last."; a card's top edge on hover | automatic |
| Tape | bottom edge of the homepage hero on load; the four `.steps` connect in sequence | automatic |
| Spirit level | `<div class="level" aria-hidden="true"><span class="vial"><i></i></span><span>Label</span></div>` | place by hand (index, about, for-architects) |
| Dovetail | `<div class="joint" aria-hidden="true"></div>` immediately before `<footer>` on every page | amp.js fills it and matches the upper piece to the section above |
| Plotter | planner and shade-study SVGs draw line-by-line on every change | `window.ampPlot(svg)` |
| Hinge | nav dropdown swings from its top edge | automatic |
| Grain | static texture on `.deep`, `.band.blue`, `.ftr` | automatic |

Rules: transform / opacity / clip-path only. Everything is gated behind `html.craft`,
which amp.js sets only when the visitor has *not* asked for reduced motion — with no
JS, or with that preference, every element renders in its finished static state.
Nothing loops except the marquee and the availability dot, which already did.
