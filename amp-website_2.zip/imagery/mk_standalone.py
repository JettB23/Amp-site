#!/usr/bin/env python3
"""Rebuild /standalone/ — one self-contained HTML file per page.

CSS, JS, logos and photography are all inlined. Photography is downscaled to a
review resolution first, so the review files stay a sane size; the deployable
site at the root keeps the full-resolution assets.
"""
import io, os, re, glob, base64
from PIL import Image

OUT      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REVIEW_PX= 1800   # long edge for inlined photography — full-bleed heroes need this
REVIEW_Q = 74

css = io.open(OUT+"/assets/css/amp.css", encoding="utf-8").read()
js  = io.open(OUT+"/assets/js/amp.js",  encoding="utf-8").read()

def b64(path, mime):
    return "data:%s;base64,%s" % (mime, base64.b64encode(open(path,"rb").read()).decode())

# logos, inlined as-is
logos = {}
for n in ["amp-logo.png","amp-logo-light.png","amp-mark.png","amp-mark-light.png"]:
    p = OUT+"/assets/"+n
    if os.path.exists(p): logos["assets/"+n] = b64(p,"image/png")

# photography, downscaled once and cached
_photo = {}
def photo(rel):
    if rel in _photo: return _photo[rel]
    src = OUT+"/"+rel
    if not os.path.exists(src):
        base = os.path.splitext(src)[0]
        src = next((base+e for e in (".jpg",".webp",".png",".avif") if os.path.exists(base+e)), None)
        if not src: return None
    im = Image.open(src).convert("RGB")
    w,h = im.size
    if max(w,h) > REVIEW_PX:
        s = REVIEW_PX/max(w,h); im = im.resize((round(w*s),round(h*s)), Image.LANCZOS)
    buf = io.BytesIO(); im.save(buf,"WEBP",quality=REVIEW_Q,method=6)
    _photo[rel] = "data:image/webp;base64,"+base64.b64encode(buf.getvalue()).decode()
    return _photo[rel]

# <picture><source avif><source webp><img jpg></picture>  ->  <picture><img inlined></picture>
PIC = re.compile(r'<picture(\s+class="ph-img[^"]*")>(.*?)</picture>', re.S)
def flatten(m):
    attrs, inner = m.group(1), m.group(2)
    img = re.search(r'<img\b[^>]*>', inner)
    if not img: return m.group(0)
    tag = img.group(0)
    src = re.search(r'src="([^"]+)"', tag)
    if src:
        d = photo(src.group(1))
        if d: tag = tag.replace(src.group(0), 'src="%s"' % d)
    return "<picture%s>%s</picture>" % (attrs, tag)

os.makedirs(OUT+"/standalone", exist_ok=True)
done = 0
for f in sorted(glob.glob(OUT+"/*.html")):
    s = io.open(f, encoding="utf-8").read()
    s = s.replace('<link rel="stylesheet" href="assets/css/amp.css">', "<style>\n"+css+"\n</style>")
    s = s.replace('<script src="assets/js/amp.js" defer></script>', "<script>\n"+js+"\n</script>")
    s = PIC.sub(flatten, s)
    for k,v in logos.items():
        s = s.replace('="'+k+'"', '="'+v+'"')
    bad = re.findall(r'(?:href|src|srcset)="assets/[^"]*"', s)
    assert not bad, (os.path.basename(f), bad[:3])
    assert "<style>" in s and "function" in s, os.path.basename(f)
    io.open(OUT+"/standalone/"+os.path.basename(f), "w", encoding="utf-8").write(s)
    done += 1
print("standalone regenerated:", done)
