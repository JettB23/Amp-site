#!/usr/bin/env python3
"""
Drop images into the AMP site.

Put files in imagery/src/ named by shot id:  idx-hero.jpg, pg-detail.png, ...
(ids are in shotlist.json).  Then:  python3 imagery/apply.py

Builds AVIF+WebP+JPEG at the right crop, writes assets/img/, replaces the
matching <div class="ph ..."> placeholder with a <picture>, and regenerates
/standalone/.  Placeholders with no matching file are left exactly as they are,
so you can add photography a few at a time.
"""
import json, os, re, io, sys, glob, subprocess
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG  = os.path.join(ROOT, "assets", "img")
SRC  = os.path.join(ROOT, "imagery", "src")
SHOTS= json.load(open(os.path.join(ROOT,"imagery","shotlist.json")))["shots"]
LONG = 1800            # long-edge px of the master
Q    = 74

def crop_to(im, ar, focus=0.5):
    """focus: where the crop window centres on the axis being trimmed
    (0 = left/top edge, 0.5 = centre, 1 = right/bottom edge)."""
    w,h = ar; target = w/h
    iw,ih = im.size; cur = iw/ih
    if cur > target:                      # too wide -> trim sides
        nw = int(ih*target); x0 = round((iw-nw)*focus)
        im = im.crop((x0,0,x0+nw,ih))
    elif cur < target:                    # too tall -> trim top/bottom
        nh = int(iw/target); y0 = round((ih-nh)*focus)
        im = im.crop((0,y0,iw,y0+nh))
    iw,ih = im.size
    if max(iw,ih) > LONG:
        s = LONG/max(iw,ih); im = im.resize((round(iw*s),round(ih*s)), Image.LANCZOS)
    return im

def main():
    os.makedirs(IMG, exist_ok=True)
    applied, skipped = [], []
    by_page = {}
    for s in SHOTS:
        hit = glob.glob(os.path.join(SRC, s["id"]+".*"))
        if not hit: skipped.append(s["id"]); continue
        ar = tuple(int(x) for x in s["ar"].split(":"))
        im = crop_to(Image.open(hit[0]).convert("RGB"), ar, s.get("focus",0.5))
        base = os.path.join(IMG, s["id"])
        im.save(base+".jpg", quality=Q, optimize=True, progressive=True)
        im.save(base+".webp", quality=Q, method=6)
        try: im.save(base+".avif", quality=Q)
        except Exception: pass
        s["_w"], s["_h"] = im.size
        by_page.setdefault(s["page"], []).append(s)
        applied.append(s["id"])

    for page, shots in by_page.items():
        p = os.path.join(ROOT, page)
        html = io.open(p, encoding="utf-8").read()
        # every placeholder on the page, in document order
        phs = list(re.finditer(
            r'<div class="ph ([a-z0-9\- ]*)"[^>]*aria-label="Photography placeholder: [^"]*".*?</div>\s*</div>',
            html, re.S))
        for s in sorted(shots, key=lambda x:-x["slot"]):   # back to front: offsets stay valid
            if s["slot"] >= len(phs):
                print(f"  !! {page} slot {s['slot']} out of range ({len(phs)} placeholders)"); continue
            m = phs[s["slot"]]
            ratio = m.group(1).strip()
            eager = ' loading="eager" fetchpriority="high"' if s["slot"]==0 else ' loading="lazy"'
            pic = (f'<picture class="ph-img {ratio}">'
                   f'<source srcset="assets/img/{s["id"]}.avif" type="image/avif">'
                   f'<source srcset="assets/img/{s["id"]}.webp" type="image/webp">'
                   f'<img src="assets/img/{s["id"]}.jpg" alt="{s["alt"]}" '
                   f'width="{s["_w"]}" height="{s["_h"]}"{eager} decoding="async"></picture>')
            html = html[:m.start()] + pic + html[m.end():]
        io.open(p,"w",encoding="utf-8").write(html)
        print(f"  {page}: {len(shots)} image(s) placed")

    print(f"\napplied {len(applied)}  |  still placeholder: {len(skipped)}")
    if skipped: print("  missing:", " ".join(skipped))
    gen = os.path.join(ROOT,"imagery","mk_standalone.py")
    if os.path.exists(gen):
        subprocess.run([sys.executable, gen], check=True)

if __name__ == "__main__":
    main()
