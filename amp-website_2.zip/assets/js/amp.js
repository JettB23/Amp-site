/* ==========================================================================
   AMP — shared behaviour. No dependencies.
   Everything degrades: content is in the HTML, reveals default to visible.
   ========================================================================== */
(function(){
  'use strict';
  var reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $  = function(s,c){ return (c||document).querySelector(s); };
  var $$ = function(s,c){ return Array.prototype.slice.call((c||document).querySelectorAll(s)); };

  /* ── header state + mobile dock ─────────────────────────────────────── */
  var hdr=$('.hdr'), dock=$('.dock');
  function onScroll(){
    if(hdr)  hdr.classList.toggle('stuck', scrollY > 12);
    if(dock) dock.classList.toggle('up', scrollY > 320);
  }
  addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  /* ── desktop dropdowns ──────────────────────────────────────────────── */
  $$('[data-drop]').forEach(function(btn){
    var menu = $('#'+btn.getAttribute('aria-controls'));
    if(!menu) return;
    function set(open){
      btn.setAttribute('aria-expanded', open);
      menu.classList.toggle('open', open);
    }
    btn.addEventListener('click', function(e){
      e.stopPropagation();
      var open = btn.getAttribute('aria-expanded')!=='true';
      $$('[data-drop]').forEach(function(o){
        if(o!==btn){ o.setAttribute('aria-expanded','false');
          var m=$('#'+o.getAttribute('aria-controls')); if(m) m.classList.remove('open'); }
      });
      set(open);
    });
    /* stays open until a click outside, Escape, or choosing a link */
    document.addEventListener('click', function(e){ if(!btn.parentElement.contains(e.target)) set(false); });
    addEventListener('keydown', function(e){ if(e.key==='Escape') set(false); });
  });

  /* ── mobile sheet ───────────────────────────────────────────────────── */
  var burger=$('#burger'), sheet=$('#sheet');
  if(burger && sheet){
    var lbl = $('#burgerLabel');
    function setSheet(open){
      burger.setAttribute('aria-expanded', open);
      sheet.classList.toggle('open', open);
      sheet.setAttribute('aria-hidden', !open);
      document.body.classList.toggle('locked', open);
      if(lbl) lbl.textContent = open ? 'Close' : 'Menu';
    }
    burger.addEventListener('click', function(){ setSheet(burger.getAttribute('aria-expanded')!=='true'); });
    sheet.addEventListener('click', function(e){ if(e.target.closest('a')) setSheet(false); });
    addEventListener('keydown', function(e){ if(e.key==='Escape') setSheet(false); });
  }

  /* ── reveals ────────────────────────────────────────────────────────── */
  /* html.craft switches on the carpentry motion (amp.css §27). It is set
     only here, only when the visitor has not asked for reduced motion, so
     with no JS — or with that preference — every animated element renders
     in its finished state and nothing on the page depends on movement.
     The same observer that reveals .rv blocks also fires the craft pieces:
     kickers draw their pencil line, tick lists stroke in, the level settles,
     the dovetail seats, the hero lays its tape. */
  if(!reduced) document.documentElement.classList.add('craft');
  var rv = $$('.rv, .eyebrow, ul.ticks, .level, .joint, .steps, .hero-full');
  if(reduced || !('IntersectionObserver' in window)){
    rv.forEach(function(el){ el.classList.add('in'); });
  } else {
    var io = new IntersectionObserver(function(en){
      en.forEach(function(e){
        if(!e.isIntersecting) return;
        e.target.classList.add('in');
        io.unobserve(e.target);
      });
    },{rootMargin:'0px 0px -7% 0px', threshold:0.06});
    rv.forEach(function(el){ io.observe(el); });
    /* safety net for anything the observer misses */
    /* Anything at or above the fold has been reached by the reader, so it
       must be visible — including sections already scrolled well past,
       which a fast programmatic scroll can skip past the observer. */
    var sweep=function(){
      rv.forEach(function(el){
        if(el.getBoundingClientRect().top < innerHeight*1.05) el.classList.add('in');
      });
    };
    setTimeout(sweep,1200);
    /* Failsafe: whatever the observer and the sweep both miss becomes
       visible anyway. Losing an animation is fine; losing content is not. */
    /* …but only for content. The craft pieces are decoration: if the
       observer never reaches them nothing is lost, whereas forcing them
       here would play the dovetail and the level off-screen, unseen. */
    setTimeout(function(){ rv.forEach(function(el){ if(el.classList.contains('rv')) el.classList.add('in'); }); }, 2600);
    var queued=false;
    addEventListener('scroll',function(){
      if(queued) return; queued=true;
      requestAnimationFrame(function(){ sweep(); queued=false; });
    },{passive:true});
  }

  /* ── counters ───────────────────────────────────────────────────────── */
  $$('[data-count]').forEach(function(el){
    var to=parseFloat(el.dataset.count), pre=el.dataset.prefix||'', suf=el.dataset.suffix||'', ran=false;
    function run(){
      if(ran) return; ran=true;
      if(reduced){ el.textContent=pre+to+suf; return; }
      var t0=null;
      (function tick(t){
        if(!t0) t0=t;
        var p=Math.min((t-t0)/1000,1), e=1-Math.pow(1-p,3);
        el.textContent = pre + Math.round(to*e) + suf;
        if(p<1) requestAnimationFrame(tick);
      })(performance.now());
    }
    if(!('IntersectionObserver' in window)) return run();
    var o=new IntersectionObserver(function(en){ if(en[0].isIntersecting){ run(); o.disconnect(); } },{threshold:.45});
    o.observe(el);
  });

  /* ── availability month, from the stated 4–6 week lead time ─────────── */
  (function(){
    var els=$$('[data-book-month]');
    if(!els.length) return;
    var d=new Date(); d.setDate(d.getDate()+35);
    var m=d.toLocaleDateString('en-ZA',{month:'long'});
    m=m.charAt(0).toUpperCase()+m.slice(1);
    els.forEach(function(el){ el.textContent=m; el.classList.remove('tk'); });
  })();

  /* ── multi-step enquiry ─────────────────────────────────────────────── */
  var form=$('#enq');
  if(form){
    var steps=$$('.fstep',form), cur=1, total=steps.length;
    var pbar=$('#pbar'), pnum=$('#pnum'), live=$('#live'), review=$('#review'), done=$('#done');
    var LABELS={project_type:'Project',area:'Area',scope:'Scope',start:'Timing',budget:'Budget',ref:'Heard via'};

    function show(n){
      cur=Math.min(Math.max(n,1),total);
      steps.forEach(function(s){ s.classList.toggle('on', +s.dataset.step===cur); });
      if(pnum) pnum.textContent='Step '+cur+' of '+total;
      if(pbar) pbar.style.width=(cur/total*100)+'%';
      if(live) live.textContent='Step '+cur+' of '+total;
      if(cur===total) buildReview();
      var card=$('.form-card'), top=card.getBoundingClientRect().top+scrollY-100;
      if(scrollY>top+160) scrollTo({top:top, behavior: reduced?'auto':'smooth'});
    }
    function fields(step){
      return $$('input,select,textarea',step).filter(function(f){ return f.name && f.name!=='company'; });
    }
    function setErr(n,m){ var p=$('[data-err="'+n+'"]',form); if(p) p.textContent=m||''; }
    function validate(step){
      var ok=true, first=null, groups={};
      fields(step).forEach(function(f){
        if(f.type==='radio'){ (groups[f.name]=groups[f.name]||[]).push(f); return; }
        if(!f.required) return;
        var bad = f.type==='checkbox' ? !f.checked
                : !f.value.trim() ? true
                : f.type==='email' ? !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.value)
                : f.type==='tel'   ? f.value.replace(/\D/g,'').length < 9
                : false;
        f.setAttribute('aria-invalid', bad);
        setErr(f.name, bad ? (f.type==='email' ? 'Please enter a valid email address'
                            : f.type==='tel'   ? 'Please enter a number we can reach you on'
                            : f.type==='checkbox' ? 'Please tick this to continue'
                            : 'We need this one') : '');
        if(bad){ ok=false; first=first||f; }
      });
      Object.keys(groups).forEach(function(n){
        var g=groups[n];
        if(g[0].required && !g.some(function(r){ return r.checked; })){ ok=false; setErr(n,'Pick one to continue'); first=first||g[0]; }
        else setErr(n,'');
      });
      if(first){ first.focus(); if(live) live.textContent='Please check the highlighted field.'; }
      return ok;
    }
    function values(){
      var o={}; new FormData(form).forEach(function(v,k){ if(k!=='company'&&String(v).trim()) o[k]=v; });
      return o;
    }
    function buildReview(){
      if(!review) return;
      var v=values(); review.innerHTML='';
      Object.keys(LABELS).forEach(function(k){
        if(!v[k]) return;
        var d=document.createElement('div');
        d.innerHTML='<dt>'+LABELS[k]+'</dt><dd>'+String(v[k]).replace(/[<>]/g,'')+'</dd>';
        review.appendChild(d);
      });
      if(!review.children.length) review.innerHTML='<div><dt>Summary</dt><dd>Your answers appear here</dd></div>';
    }
    $$('[data-next]',form).forEach(function(b){
      b.addEventListener('click',function(){ if(validate(b.closest('.fstep'))) show(cur+1); });
    });
    $$('[data-back]',form).forEach(function(b){
      b.addEventListener('click',function(){ show(cur-1); });
    });
    $$('.opt input',form).forEach(function(r){
      r.addEventListener('change',function(){ setErr(r.name,''); });
    });
    form.addEventListener('submit',function(e){
      e.preventDefault();
      if($('#company',form) && $('#company',form).value) return;
      if(!validate(steps[total-1])) return;
      var v=values(), endpoint=form.getAttribute('action');
      if(endpoint){
        fetch(endpoint,{method:'POST',headers:{Accept:'application/json'},body:new FormData(form)})
          .then(finish).catch(function(){ mail(v); finish(); });
      } else { mail(v); finish(); }
    });
    function mail(v){
      var L=['New project enquiry from the AMP website',''];
      Object.keys(LABELS).forEach(function(k){ if(v[k]) L.push(LABELS[k]+': '+v[k]); });
      L.push('','Details:',v.detail||'','','Contact:','Name: '+(v.name||''),'Phone: '+(v.phone||''),'Email: '+(v.email||''));
      location.href='mailto:'+(form.dataset.to||'[EMAIL_ADDRESS]')
        +'?subject='+encodeURIComponent('Website enquiry — '+(v.project_type||'Project')+' — '+(v.area||''))
        +'&body='+encodeURIComponent(L.join('\n'));
    }
    function finish(){
      form.style.display='none';
      var hd=$('.form-hd'); if(hd) hd.style.display='none';
      if(done){ done.classList.add('on'); done.scrollIntoView({block:'center',behavior:reduced?'auto':'smooth'}); }
      if(live) live.textContent='Enquiry sent. Thank you.';
    }
  }

  /* ── year ───────────────────────────────────────────────────────────── */
  $$('[data-year]').forEach(function(el){ el.textContent=new Date().getFullYear(); });
})();

/* ==========================================================================
   BUILD PLANNER — parametric elevation + spec summary.
   No pricing: every AMP job is quoted individually. Instead the planner
   reports which cost drivers a spec touches, which is honest and still
   sets expectations before the site visit.
   ========================================================================== */
(function(){
  'use strict';
  var root = document.getElementById('planner');
  if(!root) return;

  var S = { type:'pergola', width:5, depth:3.5, height:2.7,
            roof:'louvred', attach:'free',
            braai:'wood', sink:true, fridge:false, top:'granite',
            level:'raised', rail:true, steps:true,
            config:'mixed' };

  var W=800, H=460, GY=396;                 /* sheet + ground line */
  var el = function(id){ return document.getElementById(id); };
  var esc= function(s){ return String(s).replace(/[<>&]/g,''); };

  /* ── drawing helpers ──────────────────────────────────────────────── */
  function hatch(x0,x1,y){
    var o='',x;
    for(x=x0;x<x1;x+=42) o+='<path class="pl-hatch" d="M'+x+' '+y+' L'+(x-18)+' '+(y+18)+'"/>';
    return o;
  }
  function dimH(x0,x1,y,label){
    return '<path class="pl-dim" d="M'+x0+' '+y+' h'+(x1-x0)+'"/>'
         + '<path class="pl-dim" d="M'+x0+' '+(y-6)+' v12"/><path class="pl-dim" d="M'+x1+' '+(y-6)+' v12"/>'
         + '<text class="pl-tx" x="'+((x0+x1)/2)+'" y="'+(y-9)+'" text-anchor="middle">'+label+'</text>';
  }
  function dimV(x,y0,y1,label){
    return '<path class="pl-dim" d="M'+x+' '+y0+' v'+(y1-y0)+'"/>'
         + '<path class="pl-dim" d="M'+(x-6)+' '+y0+' h12"/><path class="pl-dim" d="M'+(x-6)+' '+y1+' h12"/>'
         + '<text class="pl-tx" x="'+(x-10)+'" y="'+((y0+y1)/2)+'" text-anchor="end">'+label+'</text>';
  }
  function m(v){ return v.toFixed(1).replace('.0','') + ' m'; }
  /* Notes sit top-right, the way they do on a real sheet, so a wide
     structure can never push a label off the paper. */
  /* One <text> with tspans, rather than one <text> per line: dy in em means
     the leading follows whatever font-size the stylesheet is using, so the
     block stays readable when the phone breakpoint scales the type up
     instead of collapsing into three overlapping lines. */
  function notes(list){
    return '<text class="pl-tx lbl" x="762" y="40" text-anchor="end">'
      + list.map(function(t,i){
          return '<tspan x="762"' + (i ? ' dy="1.45em"' : '') + '>' + t + '</tspan>';
        }).join('')
      + '</text>';
  }

  /* ── PERGOLA ──────────────────────────────────────────────────────── */
  function drawPergola(){
    var px = 74,                                   /* pixels per metre   */
        span = Math.min(S.width*px, 560),
        x0 = 400-span/2, x1 = 400+span/2,
        top = GY - S.height*px,                    /* underside of beam  */
        post = 20, o='';

    if(S.attach==='wall'){                         /* wall on the left   */
      o+='<path class="pl-fill" d="M'+(x0-34)+' '+(top-58)+' h26 v'+(GY-top+58)+' h-26 z"/>';
      o+=hatch(x0-34,x0-6,top-58).replace(/pl-hatch/g,'pl-hatch');
    }
    /* roof zone */
    var ry0 = top-34, ry1 = top-8;
    if(S.roof==='solid'){
      o+='<path class="pl-fill" d="M'+(x0-16)+' '+ry0+' h'+(span+32)+' v26 h-'+(span+32)+' z"/>';
    } else {
      o+='<path class="pl-ln th" d="M'+(x0-16)+' '+ry0+' h'+(span+32)+'"/>';
      o+='<path class="pl-ln th" d="M'+(x0-16)+' '+ry1+' h'+(span+32)+'"/>';
      var n = Math.max(4, Math.round(span/38)), i, step = span/n;
      for(i=0;i<=n;i++){
        var bx = x0 + i*step;
        o += S.roof==='louvred'
           ? '<path class="pl-ln" d="M'+bx+' '+ry1+' L'+(bx+13)+' '+ry0+'"/>'
           : '<path class="pl-ln" d="M'+bx+' '+ry0+' v26"/>';
      }
    }
    /* header beam */
    o+='<path class="pl-ln hv" d="M'+(x0-14)+' '+top+' h'+(span+28)+' v26 h-'+(span+28)+' z"/>';
    o+='<path class="pl-ln th" d="M'+(x0-14)+' '+(top+13)+' h'+(span+28)+'"/>';
    /* posts + braces + footings */
    function leg(x){
      var s='<path class="pl-ln hv" d="M'+x+' '+(top+26)+' h'+post+' v'+(GY-top-26)+' h-'+post+' z"/>';
      s+='<path class="pl-ln th" d="M'+(x-12)+' '+GY+' h'+(post+24)+' v30 h-'+(post+24)+' z"/>';
      return s;
    }
    if(S.attach!=='wall') o+=leg(x0-post/2);
    o+=leg(x1-post/2);
    function brace(x,dir){
      return '<path class="pl-ln" d="M'+x+' '+(top+92)+' L'+(x+dir*56)+' '+(top+26)+'"/>';
    }
    if(S.attach!=='wall') o+=brace(x0+post/2,1);
    o+=brace(x1-post/2,-1);
    /* ground */
    o+='<path class="pl-ln hv" d="M40 '+GY+' h720"/>'+hatch(60,760,GY);
    o+=dimH(x0,x1,GY+52,m(S.width)+' span');
    o+=dimV(x0-64,top+26,GY,m(S.height));
    o+=notes([(S.roof==='louvred'?'LOUVRED ROOF':S.roof==='solid'?'SOLID ROOF':'OPEN RAFTERS'),
              (S.attach==='wall'?'ATTACHED TO HOUSE':'FREESTANDING'),
              'CONCRETE FOOTINGS']);
    return o;
  }

  /* ── OUTDOOR KITCHEN ──────────────────────────────────────────────── */
  function drawKitchen(){
    var px = 92,
        run = Math.min(S.width*px, 600),
        x0 = 400-run/2, x1 = 400+run/2,
        cy = 244, o='';                            /* worktop top edge   */

    o+='<path class="pl-ln th" d="M'+(x0-30)+' 128 h'+(run+60)+'"/>';   /* back wall */

    if(S.braai!=='none'){
      var bw = Math.min(150, run*0.34), bx = 400-bw/2;
      o+='<path class="pl-ln hv" d="M'+bx+' '+cy+' h'+bw+' v-84 h-'+bw+' z"/>';
      o+='<path class="pl-ln th" d="M'+(bx+12)+' '+(cy-22)+' h'+(bw-24)+'"/>';
      o+='<path class="pl-ln th" d="M'+(bx+12)+' '+(cy-44)+' h'+(bw-24)+'"/>';
      if(S.braai!=='gas'){                          /* wood needs a flue */
        o+='<path class="pl-ln hv" d="M'+(bx-14)+' '+(cy-84)+' L'+(bx+bw+14)+' '+(cy-84)
          +' L'+(400+34)+' 96 L'+(400-34)+' 96 z"/>';
        o+='<path class="pl-ln" d="M'+(400-19)+' 96 h38 v-30 h-38 z"/>';
      }
      o+='<text class="pl-tx lbl" x="400" y="'+(cy-96)+'" text-anchor="middle">'
        +(S.braai==='both'?'WOOD + GAS':S.braai==='gas'?'GAS BRAAI':'WOOD BRAAI')+'</text>';
    }
    /* worktop + carcass */
    o+='<path class="pl-fill" d="M'+(x0-14)+' '+cy+' h'+(run+28)+' v18 h-'+(run+28)+' z"/>';
    o+='<path class="pl-ln hv" d="M'+x0+' '+(cy+18)+' h'+run+' v'+(GY-22-cy-18)+' h-'+run+' z"/>';
    /* bays */
    var bays = Math.max(2, Math.round(run/118)), i, bw2 = run/bays;
    for(i=1;i<bays;i++) o+='<path class="pl-ln" d="M'+(x0+i*bw2)+' '+(cy+18)+' v'+(GY-22-cy-18)+'"/>';
    for(i=0;i<bays;i++){
      var hx = x0 + i*bw2 + bw2/2;
      o+='<path class="pl-ln th" d="M'+(hx-16)+' '+(cy+92)+' h32"/>';
    }
    if(S.sink)   o+='<path class="pl-ln" d="M'+(x0+20)+' '+(cy+4)+' h58 v10 h-58 z"/>'
                  + '<text class="pl-tx lbl" x="'+(x0+49)+'" y="'+(cy-10)+'" text-anchor="middle">SINK</text>';
    if(S.fridge) o+='<path class="pl-ln" d="M'+(x1-bw2+8)+' '+(cy+26)+' h'+(bw2-16)+' v'+(GY-30-cy-26)+' h-'+(bw2-16)+' z"/>'
                  + '<text class="pl-tx lbl" x="'+(x1-bw2/2)+'" y="'+(GY-4)+'" text-anchor="middle">FRIDGE</text>';
    o+='<path class="pl-ln" d="M'+(x0+6)+' '+(GY-22)+' h'+(run-12)+' v10 h-'+(run-12)+' z"/>';
    o+='<path class="pl-ln hv" d="M40 '+GY+' h720"/>'+hatch(60,760,GY);
    o+=dimH(x0,x1,GY+52,m(S.width)+' counter run');
    var kn=[S.top.toUpperCase()+' WORKTOP'];
    if(S.sink) kn.push('SINK + PLUMBING');
    if(S.fridge) kn.push('FRIDGE HOUSING');
    o+=notes(kn);
    return o;
  }

  /* ── DECKING ──────────────────────────────────────────────────────── */
  function drawDeck(){
    var px = 74,
        run = Math.min(S.width*px, 580),
        x0 = 400-run/2, x1 = 400+run/2,
        deckY = S.level==='raised' ? 210 : 316,
        o='';

    if(S.rail){
      o+='<path class="pl-ln hv" d="M'+(x1-18)+' '+(deckY-96)+' h18 v96 h-18 z"/>';
      o+='<path class="pl-ln" d="M'+(x0+40)+' '+(deckY-84)+' h'+(run-40)+' v12 h-'+(run-40)+' z"/>';
      var r,rn=Math.max(3,Math.round(run/72));
      for(r=1;r<rn;r++) o+='<path class="pl-ln th" d="M'+(x0+40+r*((run-40)/rn))+' '+(deckY-72)+' v72"/>';

    }
    /* boards in section */
    var n=Math.max(6,Math.round(run/30)), i, bw=run/n;
    for(i=0;i<n;i++) o+='<path class="pl-ln" d="M'+(x0+i*bw+1.5)+' '+deckY+' h'+(bw-4)+' v14 h-'+(bw-4)+' z"/>';
    /* joists, bearer, piers */
    o+='<path class="pl-fill" d="M'+x0+' '+(deckY+14)+' h'+run+' v26 h-'+run+' z"/>';
    var j,jn=Math.max(4,Math.round(run/64));
    for(j=1;j<jn;j++) o+='<path class="pl-ln th" d="M'+(x0+j*(run/jn))+' '+(deckY+14)+' v26"/>';
    o+='<path class="pl-ln hv" d="M'+(x0+10)+' '+(deckY+40)+' h'+(run-20)+' v18 h-'+(run-20)+' z"/>';
    var p,pn=Math.max(2,Math.round(run/150));
    for(p=0;p<=pn;p++){
      var pxx = x0+22 + p*((run-44)/pn);
      o+='<path class="pl-ln hv" d="M'+(pxx-11)+' '+(deckY+58)+' h22 v'+(GY-deckY-58)+' h-22 z"/>';
      o+='<path class="pl-ln th" d="M'+(pxx-22)+' '+GY+' h44 v16 h-44 z"/>';
    }
    if(S.steps){
      var sy=deckY+14, sx=x0-12, k;
      for(k=0;k<3;k++) o+='<path class="pl-ln" d="M'+(sx-k*30-30)+' '+(sy+(k+1)*((GY-sy)/4))
        +' h30 v'+((GY-sy)/4)+' h-30 z"/>';
      o+='<text class="pl-tx lbl" x="'+(sx-56)+'" y="'+(sy-10)+'" text-anchor="middle">STEPS</text>';
    }
    o+='<path class="pl-ln hv" d="M40 '+GY+' h720"/>'+hatch(60,760,GY);
    o+=dimH(x0,x1,GY+52,m(S.width)+' × '+m(S.depth));
    var dn=[S.level==='raised'?'RAISED DECK':'GROUND LEVEL','JOISTS + BEARERS ON PIERS'];
    if(S.rail) dn.push('BALUSTRADE');
    if(S.steps) dn.push('STEPS DOWN');
    o+=notes(dn);
    return o;
  }

  /* ── CABINETRY ────────────────────────────────────────────────────── */
  function drawCab(){
    var px = 96,
        run = Math.min(S.width*px, 580),
        x0 = 400-run/2, x1 = 400+run/2,
        top = GY - 28 - S.height*74, o='';

    o+='<path class="pl-ln th" d="M'+(x0-34)+' '+(top-30)+' h'+(run+68)+'"/>';
    o+='<path class="pl-ln hv" d="M'+x0+' '+top+' h'+run+' v'+(GY-28-top)+' h-'+run+' z"/>';
    var bays=Math.max(2,Math.round(run/150)), i, bw=run/bays;
    for(i=1;i<bays;i++) o+='<path class="pl-ln hv" d="M'+(x0+i*bw)+' '+top+' v'+(GY-28-top)+'"/>';
    for(i=0;i<bays;i++){
      var bx=x0+i*bw, isDrawer = (S.config==='drawers') || (S.config==='mixed' && i%2===1);
      if(isDrawer){
        var d,dn=3;
        for(d=0;d<dn;d++){
          var dy = top + 12 + d*((GY-28-top-24)/dn);
          o+='<path class="pl-ln" d="M'+(bx+10)+' '+dy+' h'+(bw-20)+' v'+((GY-28-top-24)/dn-8)+' h-'+(bw-20)+' z"/>';
          o+='<path class="pl-ln th" d="M'+(bx+bw/2-16)+' '+(dy+((GY-28-top-24)/dn-8)/2)+' h32"/>';
        }
      } else {
        o+='<path class="pl-ln" d="M'+(bx+10)+' '+(top+12)+' h'+(bw-20)+' v'+(GY-28-top-24)+' h-'+(bw-20)+' z"/>';
        o+='<path class="pl-ln th" d="M'+(bx+bw-26)+' '+(top+(GY-28-top)/2-16)+' v32"/>';
        var sh,shn=3;
        for(sh=1;sh<shn;sh++) o+='<path class="pl-ln th" d="M'+(bx+14)+' '+(top+sh*((GY-28-top)/shn))+' h'+(bw-28)+'"/>';
      }
    }
    o+='<path class="pl-ln" d="M'+(x0+8)+' '+(GY-28)+' h'+(run-16)+' v18 h-'+(run-16)+' z"/>';
    o+='<path class="pl-ln hv" d="M40 '+GY+' h720"/>'+hatch(60,760,GY);
    o+=dimH(x0,x1,GY+52,m(S.width)+' run');
    o+=dimV(x0-58,top,GY-28,m(S.height));
    o+=notes([S.config==='drawers'?'DRAWERS THROUGHOUT':S.config==='doors'?'DOORS + SHELVING':'DOORS + DRAWERS',
              'WEATHER-RATED HARDWARE']);
    return o;
  }

  var DRAW = {pergola:drawPergola, kitchen:drawKitchen, deck:drawDeck, cabinetry:drawCab};
  var NAME = {pergola:'Pergola', kitchen:'Outdoor kitchen', deck:'Decking', cabinetry:'Built-in cabinetry'};
  var VIEW = {pergola:'Front elevation', kitchen:'Front elevation', deck:'Typical section', cabinetry:'Front elevation'};

  /* ── cost drivers (relative, never a price) ───────────────────────── */
  function drivers(){
    var size = S.type==='deck' ? (S.width*S.depth)/48 : S.width/8;
    var mat  = 0.3, svc = 0.15, cx = 0.3;
    if(S.type==='pergola'){
      if(S.roof==='louvred') mat+=0.45; else if(S.roof==='solid') mat+=0.3; else mat+=0.1;
      if(S.height>2.9) cx+=0.15;
      if(S.attach==='wall') cx+=0.1;
    }
    if(S.type==='kitchen'){
      if(S.braai==='both') {mat+=0.4; svc+=0.35;} else if(S.braai==='gas') {mat+=0.25; svc+=0.3;}
      else if(S.braai==='wood'){ mat+=0.3; svc+=0.1; }
      if(S.sink){ svc+=0.4; cx+=0.1; }
      if(S.fridge) svc+=0.25;
      if(S.top==='granite') mat+=0.3; else if(S.top==='concrete') mat+=0.2; else mat+=0.1;
    }
    if(S.type==='deck'){
      if(S.level==='raised'){ cx+=0.35; mat+=0.2; }
      if(S.rail) mat+=0.25;
      if(S.steps){ cx+=0.15; mat+=0.1; }
    }
    if(S.type==='cabinetry'){
      mat += S.config==='drawers' ? 0.45 : S.config==='mixed' ? 0.3 : 0.15;
    }
    var cl=function(v){ return Math.max(0.12, Math.min(1, v)); };
    return [['Size &amp; span',cl(size)],['Materials &amp; hardware',cl(mat)],
            ['Services to run in',cl(svc)],['Site complexity',cl(cx)]];
  }
  function band(v){ return v<0.38?'Modest':v<0.68?'Moderate':'Significant'; }

  /* ── spec summary ─────────────────────────────────────────────────── */
  function spec(){
    var r=[['Build', NAME[S.type]]];
    if(S.type==='deck') r.push(['Size', m(S.width)+' × '+m(S.depth)]);
    else if(S.type==='cabinetry') r.push(['Run', m(S.width)],['Height', m(S.height)]);
    else r.push(['Width', m(S.width)]);
    if(S.type==='pergola') r.push(['Height', m(S.height)],
      ['Roof', S.roof==='louvred'?'Louvred':S.roof==='solid'?'Solid':'Open rafters'],
      ['Mounting', S.attach==='wall'?'Attached to the house':'Freestanding']);
    if(S.type==='kitchen') r.push(
      ['Braai', S.braai==='both'?'Wood and gas':S.braai==='gas'?'Gas':S.braai==='none'?'None':'Wood'],
      ['Worktop', S.top.charAt(0).toUpperCase()+S.top.slice(1)],
      ['Sink', S.sink?'Yes':'No'], ['Fridge housing', S.fridge?'Yes':'No']);
    if(S.type==='deck') r.push(['Level', S.level==='raised'?'Raised':'Ground level'],
      ['Balustrade', S.rail?'Yes':'No'], ['Steps', S.steps?'Yes':'No']);
    if(S.type==='cabinetry') r.push(['Layout',
      S.config==='drawers'?'Drawers throughout':S.config==='doors'?'Doors and shelving':'Doors and drawers']);
    return r;
  }

  /* ── render ───────────────────────────────────────────────────────── */
  function render(){
    el('plSvg').innerHTML = DRAW[S.type]();
    if(window.ampPlot) window.ampPlot(el('plSvg'));
    el('plName').textContent = NAME[S.type];
    el('plView').textContent = VIEW[S.type];

    el('plSpec').innerHTML = spec().map(function(r){
      return '<div><dt>'+r[0]+'</dt><dd>'+r[1]+'</dd></div>'; }).join('');

    el('plDrivers').innerHTML = drivers().map(function(d){
      return '<div class="pl-driver"><span class="k">'+d[0]+'</span>'
           + '<span class="bar"><i style="width:'+Math.round(d[1]*100)+'%"></i></span>'
           + '<span class="tag">'+band(d[1])+'</span></div>'; }).join('');

    /* show only the controls that belong to this build */
    Array.prototype.forEach.call(root.querySelectorAll('[data-for]'), function(g){
      g.hidden = g.getAttribute('data-for').split(' ').indexOf(S.type) === -1;
    });
    /* depth only matters for a deck */
    var d=el('grpDepth'); if(d) d.hidden = S.type!=='deck';
    var h=el('grpHeight'); if(h) h.hidden = (S.type!=='pergola' && S.type!=='cabinetry');

    var line = spec().map(function(r){ return r[0]+': '+r[1]; }).join('\n');
    if(root.dataset.shadeLine) line += '\n' + root.dataset.shadeLine;
    root.dataset.spec = line;
    document.dispatchEvent(new CustomEvent('amp:plan',{detail:S}));
    var send = el('plSend');
    if(send) send.href = 'contact.html?spec=' + encodeURIComponent(line);
  }

  /* ── wiring ───────────────────────────────────────────────────────── */
  root.addEventListener('change', function(e){
    var t=e.target;
    if(!t.name) return;
    if(t.type==='checkbox') S[t.name] = t.checked;
    else if(t.type==='range') S[t.name] = parseFloat(t.value);
    else S[t.name] = t.value;
    var out = root.querySelector('[data-val="'+t.name+'"]');
    if(out) out.textContent = m(parseFloat(t.value));
    render();
  });
  root.addEventListener('input', function(e){
    if(e.target.type!=='range') return;
    S[e.target.name] = parseFloat(e.target.value);
    var out = root.querySelector('[data-val="'+e.target.name+'"]');
    if(out) out.textContent = m(parseFloat(e.target.value));
    render();
  });

  document.addEventListener('amp:shade', function(ev){
    root.dataset.shadeLine = ev.detail; render();
  });

  var copy = el('plCopy');
  if(copy) copy.addEventListener('click', function(){
    var txt = 'My AMP build plan\n\n' + root.dataset.spec;
    if(navigator.clipboard) navigator.clipboard.writeText(txt);
    copy.textContent = 'Copied';
    setTimeout(function(){ copy.textContent='Copy this spec'; }, 1800);
  });

  render();
})();

/* ── contact page: accept a spec handed over by the planner ─────────── */
(function(){
  var f=document.getElementById('enq'); if(!f) return;
  var q=new URLSearchParams(location.search).get('spec'); if(!q) return;
  var d=document.getElementById('detail'); if(!d) return;
  d.value = 'From the build planner —\n\n' + q + '\n\n';
  var note=document.createElement('p');
  note.className='rea'; note.style.marginTop='10px';
  note.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" '
    +'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6.5 9.5 17 4 11.6"/></svg>'
    +'Your plan has been added below.';
  d.parentNode.appendChild(note);
  /* pre-select the build type they planned, then move them past step one */
  var line=(q.split('\n')[0]||'');
  var MAP={'Pergola':'Pergola','Outdoor kitchen':'Outdoor kitchen / braai',
           'Decking':'Decking','Built-in cabinetry':'Built-in cabinetry'};
  Object.keys(MAP).forEach(function(k){
    if(line.indexOf(k)===-1) return;
    var r=f.querySelector('input[name=project_type][value="'+MAP[k]+'"]');
    if(r){ r.checked=true; var n=f.querySelector('.fstep[data-step="1"] [data-next]'); if(n) n.click(); }
  });
})();

/* ---------------------------------------------------------------------------
   THEME TOGGLE
   The applied theme is set by a tiny inline script in <head>, before first
   paint, so there is no flash of the wrong theme. This only wires the button,
   keeps the label and aria-pressed honest, and remembers the choice.

   Once a visitor chooses, that choice wins. Until then the page follows the
   operating system, and keeps following it if the OS flips mid-visit.
   ------------------------------------------------------------------------ */
(function(){
  var KEY='amp-theme', root=document.documentElement;
  var btn=document.getElementById('themeBtn'); if(!btn) return;

  function stored(){ try{ var v=localStorage.getItem(KEY);
    return (v==='light'||v==='dark')?v:null; }catch(e){ return null; } }

  function label(t){
    var next = t==='dark' ? 'light' : 'dark';
    btn.setAttribute('aria-pressed', t==='dark' ? 'true' : 'false');
    btn.setAttribute('aria-label', 'Switch to '+next+' theme');
    btn.setAttribute('title', 'Switch to '+next+' theme');
  }

  function apply(t, remember){
    root.setAttribute('data-theme', t);
    if(remember){ try{ localStorage.setItem(KEY,t); }catch(e){} }
    label(t);
  }

  label(root.getAttribute('data-theme')||'light');

  btn.addEventListener('click', function(){
    var next = root.getAttribute('data-theme')==='dark' ? 'light' : 'dark';
    /* skip the cross-fade for anyone who asked for less motion */
    if(!window.matchMedia||!matchMedia('(prefers-reduced-motion:reduce)').matches){
      root.classList.add('theming');
      window.setTimeout(function(){ root.classList.remove('theming'); }, 320);
    }
    apply(next, true);
    /* a quarter turn, like a slotted screw */
    btn.classList.remove('turn'); void btn.offsetWidth; btn.classList.add('turn');
  });

  /* follow the OS while the visitor has not expressed a preference */
  if(window.matchMedia){
    var mq=matchMedia('(prefers-color-scheme:dark)');
    var onChange=function(e){ if(!stored()) apply(e.matches?'dark':'light', false); };
    if(mq.addEventListener) mq.addEventListener('change', onChange);
    else if(mq.addListener) mq.addListener(onChange);
  }
})();

/* ---------------------------------------------------------------------------
   CLEAR HEADER OVER THE FULL-BLEED HERO
   On pages with a full-viewport hero the fixed header starts transparent,
   with light text over the photograph, and takes its normal glass background
   back as soon as the visitor scrolls (or opens the mobile menu, whose
   sheet needs the normal header colours).
   ------------------------------------------------------------------------ */
(function(){
  var hero=document.querySelector('.hero-full'); if(!hero) return;
  var hdr=document.querySelector('.hdr'); if(!hdr) return;
  function upd(){
    var clear = window.scrollY < 40 && !document.body.classList.contains('locked');
    hdr.classList.toggle('clear', clear);
  }
  window.addEventListener('scroll', upd, {passive:true});
  var burger=document.getElementById('burger');
  if(burger) burger.addEventListener('click', function(){ window.setTimeout(upd, 20); });
  upd();
})();

/* ---------------------------------------------------------------------------
   SUN & SHADE STUDIO
   Plan-view shadow cast for the Helderberg (lat 34°S), driven by season,
   time of day and louvre angle. The solar position is the standard
   declination/hour-angle model; the louvre coverage is a 2D section of
   blade width against pitch. Simplified on purpose and labelled indicative
   — the point is to let a client FEEL what a louvred roof buys them.
   It follows the size and roof set in the planner above via 'amp:plan'.
   ------------------------------------------------------------------------ */
(function(){
  var svg=document.getElementById('snSvg'); if(!svg) return;
  var $=function(id){ return document.getElementById(id); };
  var RAD=Math.PI/180, LAT=-34*RAD;
  var DECL={dec:-23.44*RAD, mar:0, jun:23.44*RAD};
  var SLAB={dec:'midsummer', mar:'autumn or spring', jun:'midwinter'};

  /* the build the shadow belongs to — kept in step with the planner */
  var B={w:5, d:3.5, h:2.7, roof:'louvred', type:'pergola'};
  var U={season:'dec', t:15, ang:35};

  document.addEventListener('amp:plan', function(ev){
    var S=ev.detail;
    B.w=S.width; B.d=(S.type==='deck'?S.depth:3.5); B.h=(S.height||2.7);
    B.type=S.type; B.roof=(S.type==='pergola'?S.roof:'louvred');
    draw();
  });

  function sun(){
    var hr=(U.t-12)*15*RAD, decl=DECL[U.season];
    var sinEl=Math.sin(LAT)*Math.sin(decl)+Math.cos(LAT)*Math.cos(decl)*Math.cos(hr);
    var el=Math.asin(sinEl);
    var cosAz=(Math.sin(decl)-Math.sin(LAT)*sinEl)/(Math.cos(LAT)*Math.cos(el)||1e-9);
    cosAz=Math.max(-1,Math.min(1,cosAz));
    var az=Math.acos(cosAz);            /* from north; morning=east side  */
    if(U.t>12) az=2*Math.PI-az;         /* afternoon mirrors to the west  */
    return {el:el, az:az};
  }
  function compass(az){
    var names=['N','NE','E','SE','S','SW','W','NW'];
    return names[Math.round((az/RAD)/45)%8];
  }
  function coverage(el){
    /* fraction of the section a blade shadow covers, per blade pitch */
    var b,p,th;
    if(B.roof==='solid') return 1;
    if(B.roof==='open'){ b=.07; p=.55; th=0; }
    else { b=.16; p=.17; th=U.ang*RAD; }
    var run=Math.abs(Math.cos(th)) + (el>.03 ? Math.sin(th)/Math.tan(el) : 30);
    return Math.min(1, b*run/p);
  }

  function draw(){
    var s=sun(), up=s.el>0.02;
    var Lm=up?Math.min(B.h/Math.tan(s.el), B.h*3.2):0;   /* shadow reach, capped for the sheet */
    var shAz=s.az+Math.PI;
    var dxm=up?Lm*Math.sin(shAz):0;                       /* east+  */
    var dym=up?Lm*Math.cos(shAz):0;                       /* north+ */

    var W=800,H=460, mx=110,mtop=84,mbot=92;
    var k=Math.min((W-2*mx)/(B.w+Math.abs(dxm)), (H-mtop-mbot)/(B.d+Math.abs(dym)));
    var fw=B.w*k, fd=B.d*k;
    var fx=(W-fw-Math.abs(dxm)*k)/2 + (dxm<0?Math.abs(dxm)*k:0);
    var fy=mtop + (dym>0?Math.abs(dym)*k:0) + (H-mtop-mbot-fd-Math.abs(dym)*k)/2;
    var sx=fx+dxm*k, sy=fy-dym*k;                         /* north up = −y  */

    var f=up?coverage(s.el):0;
    /* how much of the cast rectangle still lies on the floor */
    var ox=Math.max(0,Math.min(fx+fw,sx+fw)-Math.max(fx,sx));
    var oy=Math.max(0,Math.min(fy+fd,sy+fd)-Math.max(fy,sy));
    var pct=up?Math.round(100*f*(ox*oy)/(fw*fd)):0;

    var o='';
    /* grid + compass */
    o+='<defs><clipPath id="snFloor"><rect x="'+fx+'" y="'+fy+'" width="'+fw+'" height="'+fd+'"/></clipPath></defs>';
    o+='<path class="pl-dim" d="M60 64 v-30 M52 44 l8 -10 8 10" fill="none"/><text class="pl-tx" x="60" y="78" text-anchor="middle">N</text>';
    /* floor */
    o+='<rect class="pl-fill" x="'+fx+'" y="'+fy+'" width="'+fw+'" height="'+fd+'" rx="3"/>';
    /* shadow: faint spill, then the on-floor part, striped for louvres */
    if(up && f>0.02){
      o+='<rect x="'+sx+'" y="'+sy+'" width="'+fw+'" height="'+fd+'" fill="#000" opacity="0.10"/>';
      o+='<g clip-path="url(#snFloor)">';
      o+='<rect x="'+sx+'" y="'+sy+'" width="'+fw+'" height="'+fd+'" fill="#000" opacity="'+(0.18+0.32*f).toFixed(2)+'"/>';
      if(B.roof==='louvred'||B.roof==='open'){
        var sp=13, t=Math.max(1.4,sp*f*0.8), y0;
        for(y0=sy;y0<sy+fd;y0+=sp)
          o+='<rect x="'+sx+'" y="'+y0+'" width="'+fw+'" height="'+t+'" fill="#000" opacity="0.26"/>';
      }
      o+='</g>';
    }
    /* roof outline above it all */
    o+='<rect x="'+fx+'" y="'+fy+'" width="'+fw+'" height="'+fd+'" rx="3" fill="none" stroke="var(--blue)" stroke-width="2" stroke-dasharray="7 5"/>';
    /* sun marker on the sheet edge */
    if(up){
      var cxs=W/2+(W*0.46)*Math.sin(s.az), cys=(H/2+16)-(H*0.44)*Math.cos(s.az);
      cxs=Math.max(30,Math.min(W-30,cxs)); cys=Math.max(28,Math.min(H-36,cys));
      o+='<path d="M'+cxs+' '+cys+' L'+(fx+fw/2)+' '+(fy+fd/2)+'" stroke="var(--ochre)" stroke-width="1.6" stroke-dasharray="2 7" opacity=".55" stroke-linecap="round"/>';
      o+='<circle cx="'+cxs+'" cy="'+cys+'" r="11" fill="var(--ochre)" opacity=".9"/>';
      for(var a=0;a<8;a++){ var ax=cxs+16*Math.cos(a*Math.PI/4), ay=cys+16*Math.sin(a*Math.PI/4);
        o+='<path d="M'+(cxs+12.5*Math.cos(a*Math.PI/4))+' '+(cys+12.5*Math.sin(a*Math.PI/4))+' L'+ax+' '+ay+'" stroke="var(--ochre)" stroke-width="2" stroke-linecap="round"/>'; }
    }
    /* dimensions */
    o+='<path class="pl-dim" d="M'+fx+' '+(fy+fd+26)+' h'+fw+'"/><text class="pl-tx" x="'+(fx+fw/2)+'" y="'+(fy+fd+44)+'" text-anchor="middle">'+B.w.toFixed(1).replace('.0','')+' m</text>';
    svg.innerHTML=o;
    if(window.ampPlot) window.ampPlot(svg);

    /* readouts */
    $('snPct').textContent=pct+'%';
    $('snSize').innerHTML=B.w.toFixed(1).replace('.0','')+' &times; '+B.d.toFixed(1).replace('.0','')+' m';
    var hh=Math.floor(U.t), mm=(U.t%1)?'30':'00';
    $('snClock').textContent=(hh<10?'0':'')+hh+':'+mm;
    $('snAngV').innerHTML=U.ang+'&deg;';
    $('snLouvreGrp').hidden=(B.roof!=='louvred');
    var cap;
    if(!up){ cap='The sun is below the horizon at this hour in '+SLAB[U.season]+'. Shade is not the problem; the lighting plan is.'; }
    else{
      var deg=Math.round(s.el/RAD);
      cap='At '+$('snClock').textContent+' in '+SLAB[U.season]+', the sun stands '+deg+'&deg; high in the '+compass(s.az)
         +(B.roof==='louvred' ? '. Blades at '+U.ang+'&deg; put about '+pct+'% of the floor in shade'
           : B.roof==='solid' ? '. A solid roof shades whatever sits under it — '+pct+'% right now, with the edge creep low sun brings'
           : '. Open rafters break the light rather than block it — about '+pct+'% cover')
         +(pct<35&&deg<30 ? '. Low sun comes in from the side; planting or a screen does more than a roof here.' : '.');
    }
    $('snCap').innerHTML=cap;
  }

  document.getElementById('sun').addEventListener('input', function(e){
    if(e.target.id==='snTime') U.t=parseFloat(e.target.value);
    if(e.target.id==='snAng')  U.ang=parseInt(e.target.value,10);
    if(e.target.name==='season') U.season=e.target.value;
    var w=$('snAddWrap'); if(w) w.classList.remove('done');
    draw();
  });
  document.getElementById('sun').addEventListener('change', function(e){
    if(e.target.name==='season'){ U.season=e.target.value; draw(); }
  });
  var add=$('snAdd');
  if(add) add.addEventListener('click', function(){
    var line='Sun & shade: wants shade at '+$('snClock').textContent+' in '+SLAB[U.season]
            +(B.roof==='louvred'?', louvres around '+U.ang+'°':'')
            +' (≈'+$('snPct').textContent+' floor shade)';
    document.dispatchEvent(new CustomEvent('amp:shade',{detail:line}));
    $('snAddWrap').classList.add('done');
  });

  draw();
})();


/* ---------------------------------------------------------------------------
   CRAFT MOTION — helpers for amp.css §27
   · ampPlot(svg): re-arms the plotter draw-in on a freshly rendered sheet
   · the dovetail: fills each .joint with its two pieces and matches the
     upper piece to whatever colour sits above it on that page
   ------------------------------------------------------------------------ */
(function(){
  var root=document.documentElement;

  window.ampPlot=function(svg){
    if(!svg || !root.classList.contains('craft')) return;
    svg.classList.remove('draw'); void svg.getBoundingClientRect(); svg.classList.add('draw');
  };

  /* dovetail geometry — drawn at 1:1 (one unit = one pixel) and sliced,
     so the cut is the same on a phone as on a 4K screen rather than being
     stretched with the viewport. Tails 19 tall on a 1:5 slope, one every
     64px, the way a hand-cut through-dovetail is laid out. */
  var W=4000, P=64, TIP=5, SH=24, TW=42, BW=34;
  function tails(){
    var d='M0 30 V'+SH;
    for(var x=0;x<W;x+=P){
      var c=x+P/2, bl=c-BW/2, br=c+BW/2, tl=c-TW/2, tr=c+TW/2;
      d+=' H'+bl+' L'+tl+' '+TIP+' H'+tr+' L'+br+' '+SH;
    }
    return d+' H'+W+' V30 Z';
  }
  function seam(){
    var d='M0 '+SH;
    for(var x=0;x<W;x+=P){
      var c=x+P/2, bl=c-BW/2, br=c+BW/2, tl=c-TW/2, tr=c+TW/2;
      d+=' H'+bl+' L'+tl+' '+TIP+' H'+tr+' L'+br+' '+SH;
    }
    return d+' H'+W;
  }
  var joints=document.querySelectorAll('.joint');
  if(joints.length){
    var T=tails(), L=seam();
    Array.prototype.forEach.call(joints,function(j){
      /* colour of the last section above the joint = the upper piece */
      var prev=j.previousElementSibling, bg=null;
      while(prev && /^(SCRIPT|STYLE|TEMPLATE|LINK)$/.test(prev.tagName)) prev=prev.previousElementSibling;
      var solid=function(el){ var c=el && getComputedStyle(el).backgroundColor;
        return (c && c!=='rgba(0, 0, 0, 0)' && c!=='transparent') ? c : null; };
      if(prev){
        var kids=prev.children, i=kids.length;
        while(i-- && !bg) bg=solid(kids[i]);       /* last painted block inside <main> */
        if(!bg) bg=solid(prev);
      }
      if(!bg) bg=solid(document.body);
      if(bg) j.style.setProperty('--joint-a',bg);
      j.innerHTML='<svg viewBox="0 0 '+W+' 30" preserveAspectRatio="xMinYMid slice" aria-hidden="true">'
        +'<path class="jt-b" d="'+T+'"/>'
        +'<path class="jt-l" d="'+L+'"/></svg>';
    });
  }

  /* the planner draws once on load too */
  if(root.classList.contains('craft')){
    ['plSvg','snSvg'].forEach(function(id){ var s=document.getElementById(id); if(s && s.innerHTML.trim()) window.ampPlot(s); });
  }
})();
